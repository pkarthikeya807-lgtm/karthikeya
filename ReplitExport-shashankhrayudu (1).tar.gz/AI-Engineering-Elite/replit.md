# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── openrouter-dashboard/ # React Vite frontend dashboard
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts (single workspace package)
│   └── src/                # Individual .ts scripts
├── pnpm-workspace.yaml     # pnpm workspace
├── tsconfig.base.json      # Shared TS options
├── tsconfig.json           # Root TS project references
└── package.json            # Root package with hoisted devDeps
```

## Application: OpenRouter AI Dashboard

An intelligent LLM routing dashboard that dynamically selects the most optimal Large Language Model for every request.

### Features

- **Smart Routing Engine**: Classifies prompts as simple/moderate/complex and routes to budget/standard/premium models accordingly
- **Analytics Dashboard**: Real-time metrics — total requests, cost, savings, latency, credits earned
- **Live Prompt Tester**: Submit prompts to see routing decisions, model selection reasoning, tokens/cost/latency
- **Charts**: Line chart (requests & cost over time), Pie chart (complexity breakdown), Bar chart (model usage)
- **Request History**: Paginated table with complexity badges and model info
- **Models Page**: Grid of all available LLM models with stats
- **Credits System**: Reward credits for efficient (simple) prompt routing
- **User Profile**: API key, plan info, usage stats

### Available Models

- **Budget**: Llama 3 8B (Meta), Claude Haiku (Anthropic)
- **Standard**: Gemini 1.5 Flash (Google), GPT-4o Mini (OpenAI)
- **Premium**: GPT-4o (OpenAI), Claude Opus (Anthropic)

### API Routes

- `POST /api/route` — Route a prompt, get routing decision + mock LLM response
- `GET /api/analytics/overview` — Aggregate metrics
- `GET /api/analytics/requests` — Paginated request history
- `GET /api/analytics/timeseries` — Chart data (hour/day/week)
- `GET /api/models` — All models with stats
- `GET /api/users/me` — User profile
- `GET /api/credits/balance` — Credits balance
- `GET /api/credits/transactions` — Transaction history

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all packages as project references.

- **Always typecheck from the root** — run `pnpm run typecheck`
- **`emitDeclarationOnly`** — only emit `.d.ts` files during typecheck
- **Project references** — when package A depends on package B, A's `tsconfig.json` must list B in its `references` array

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly`
- `pnpm --filter @workspace/scripts run seed-demo` — seed 150 demo routing requests

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. Routes in `src/routes/` use `@workspace/api-zod` for validation and `@workspace/db` for persistence.

### `artifacts/openrouter-dashboard` (`@workspace/openrouter-dashboard`)

React + Vite frontend dashboard. Uses `@workspace/api-client-react` for React Query hooks.
Dependencies: recharts, framer-motion, date-fns, lucide-react

### `lib/db` (`@workspace/db`)

Database layer using Drizzle ORM with PostgreSQL.
- `routing_requests` table — stores all routing decisions
- `credit_transactions` table — stores earned/spent credit events

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI spec (`openapi.yaml`) and Orval config. Run: `pnpm --filter @workspace/api-spec run codegen`

### `lib/api-zod` (`@workspace/api-zod`)

Generated Zod schemas from OpenAPI spec.

### `lib/api-client-react` (`@workspace/api-client-react`)

Generated React Query hooks and fetch client from OpenAPI spec.

### `scripts` (`@workspace/scripts`)

Utility scripts. `seed-demo.ts` seeds 150 demo routing requests into the database.
