import { Router, type IRouter } from "express";
import { randomUUID } from "crypto";
import { RoutePromptBody, RoutePromptResponse } from "@workspace/api-zod";
import { AVAILABLE_MODELS } from "./models.js";

const router: IRouter = Router();

function classifyComplexity(prompt: string): { complexity: "simple" | "moderate" | "complex"; score: number; reason: string } {
  const text = prompt.toLowerCase().trim();
  const wordCount = text.split(/\s+/).length;

  const complexIndicators = [
    /\b(analyze|analysis|research|explain|compare|evaluate|critique|design|architect|implement|debug|optimize|strategy|comprehensive|detailed|in-depth|complex|advanced|technical|expert)\b/,
    /\b(why|how does|what causes|what are the implications|walk me through|step by step)\b/,
    /\b(code|algorithm|function|class|api|database|system|architecture|framework)\b/,
    /\b(thesis|essay|report|documentation|specification)\b/,
  ];

  const simpleIndicators = [
    /^(what is|who is|when is|where is|define|list|name|tell me the|what's)/,
    /\b(translate|convert|format|summarize in one|quick|brief|short)\b/,
  ];

  let complexScore = 0;
  let simpleScore = 0;

  for (const pattern of complexIndicators) {
    if (pattern.test(text)) complexScore++;
  }
  for (const pattern of simpleIndicators) {
    if (pattern.test(text)) simpleScore++;
  }

  if (wordCount > 50) complexScore += 2;
  else if (wordCount > 20) complexScore += 1;
  else if (wordCount < 8) simpleScore += 1;

  const netScore = complexScore - simpleScore;
  let complexity: "simple" | "moderate" | "complex";
  let score: number;

  if (netScore <= 0) {
    complexity = "simple";
    score = Math.max(0.05, Math.min(0.3, 0.1 + (wordCount / 100)));
  } else if (netScore <= 2) {
    complexity = "moderate";
    score = Math.max(0.3, Math.min(0.65, 0.4 + (complexScore * 0.05)));
  } else {
    complexity = "complex";
    score = Math.max(0.65, Math.min(0.99, 0.7 + (complexScore * 0.04)));
  }

  const reasons: Record<string, string> = {
    simple: "Short, factual query with straightforward answer pattern",
    moderate: "Moderate complexity requiring some reasoning and context",
    complex: "Complex reasoning, analysis, or multi-step task detected",
  };

  return { complexity, score, reason: reasons[complexity] };
}

function selectModel(
  complexity: "simple" | "moderate" | "complex",
  preferLowCost: boolean,
  maxLatencyMs?: number
): { model: typeof AVAILABLE_MODELS[0]; alternative: typeof AVAILABLE_MODELS[0] } {
  const available = AVAILABLE_MODELS.filter((m) => {
    if (!m.isAvailable) return false;
    if (maxLatencyMs && m.avgLatencyMs > maxLatencyMs) return false;
    return true;
  });

  const budget = available.filter((m) => m.tier === "budget");
  const standard = available.filter((m) => m.tier === "standard");
  const premium = available.filter((m) => m.tier === "premium");

  let primary: typeof AVAILABLE_MODELS[0];
  let alt: typeof AVAILABLE_MODELS[0];

  if (complexity === "simple" || preferLowCost) {
    primary = budget[Math.floor(Math.random() * budget.length)];
    alt = standard[Math.floor(Math.random() * standard.length)];
  } else if (complexity === "moderate") {
    primary = standard[Math.floor(Math.random() * standard.length)];
    alt = budget[Math.floor(Math.random() * budget.length)];
  } else {
    primary = premium[Math.floor(Math.random() * premium.length)];
    alt = standard[Math.floor(Math.random() * standard.length)];
  }

  return { model: primary, alternative: alt };
}

function generateMockResponse(prompt: string, complexity: string, modelName: string): string {
  const responses: Record<string, string[]> = {
    simple: [
      `Based on your query, here's a concise answer routed via ${modelName}: The information you're looking for involves a straightforward explanation that can be provided efficiently.`,
      `${modelName} response: This is a direct answer to your question with the key facts you need, processed efficiently at minimal cost.`,
    ],
    moderate: [
      `${modelName} has analyzed your query and provides this thoughtful response: Your question requires considering multiple factors. Here's a structured breakdown of the key concepts and their relationships.`,
      `Processing your moderate-complexity request via ${modelName}: This involves several interconnected aspects that I'll address systematically for clarity.`,
    ],
    complex: [
      `${modelName} delivering comprehensive analysis: Your request involves deep technical reasoning. I'll provide a detailed, multi-faceted response covering all relevant dimensions, trade-offs, and expert-level considerations.`,
      `Advanced processing via ${modelName}: This complex query requires careful analysis. Here is an expert-level response addressing the technical depth, strategic implications, and nuanced considerations of your request.`,
    ],
  };
  const arr = responses[complexity] || responses.simple;
  return arr[Math.floor(Math.random() * arr.length)];
}

function calcCredits(complexity: string, score: number, tokensUsed: number): number {
  if (complexity === "simple" && score < 0.25) return Math.round(10 + Math.random() * 5);
  if (complexity === "moderate") return Math.round(3 + Math.random() * 3);
  return Math.round(1 + Math.random() * 2);
}

router.post("/route", async (req, res) => {
  try {
    const body = RoutePromptBody.parse(req.body);
    const { prompt, preferLowCost, maxLatencyMs } = body;

    const { complexity, score, reason } = classifyComplexity(prompt);
    const { model, alternative } = selectModel(complexity, preferLowCost ?? false, maxLatencyMs);

    const baseTokens = Math.floor(prompt.split(/\s+/).length * 1.3);
    const responseTokens = complexity === "simple" ? 80 : complexity === "moderate" ? 200 : 500;
    const tokensUsed = baseTokens + responseTokens;
    const costUsd = (tokensUsed / 1000) * model.costPer1kTokens;
    const latencyMs = model.avgLatencyMs + Math.floor(Math.random() * 200 - 100);
    const creditsEarned = calcCredits(complexity, score, tokensUsed);
    const mockResponse = generateMockResponse(prompt, complexity, model.name);
    const requestId = randomUUID();

    const { db, routingRequestsTable, creditTransactionsTable } = await import("@workspace/db");

    await db.insert(routingRequestsTable).values({
      requestId,
      userId: body.userId ?? "demo-user",
      prompt,
      complexity,
      complexityScore: score,
      selectedModelId: model.id,
      selectedModelName: model.name,
      tokensUsed,
      costUsd,
      latencyMs,
      creditsEarned,
      success: true,
      failover: false,
      routingReason: reason,
    });

    if (creditsEarned > 0) {
      await db.insert(creditTransactionsTable).values({
        transactionId: randomUUID(),
        userId: body.userId ?? "demo-user",
        type: "earned",
        amount: creditsEarned,
        reason: `Efficient routing: ${complexity} prompt → ${model.name}`,
        requestId,
      });
    }

    const data = RoutePromptResponse.parse({
      requestId,
      prompt,
      complexity,
      complexityScore: score,
      selectedModel: {
        id: model.id,
        name: model.name,
        provider: model.provider,
        tier: model.tier,
        costPer1kTokens: model.costPer1kTokens,
        avgLatencyMs: model.avgLatencyMs,
        isAvailable: model.isAvailable,
      },
      alternativeModel: {
        id: alternative.id,
        name: alternative.name,
        provider: alternative.provider,
        tier: alternative.tier,
        costPer1kTokens: alternative.costPer1kTokens,
        avgLatencyMs: alternative.avgLatencyMs,
        isAvailable: alternative.isAvailable,
      },
      response: mockResponse,
      tokensUsed,
      costUsd,
      latencyMs,
      creditsEarned,
      routingReason: reason,
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Routing error");
    res.status(400).json({ error: "routing_failed", message: String(err) });
  }
});

export default router;
