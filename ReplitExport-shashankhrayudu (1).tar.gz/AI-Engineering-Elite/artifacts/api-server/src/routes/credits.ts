import { Router, type IRouter } from "express";
import { GetCreditsBalanceResponse, GetCreditTransactionsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/credits/balance", async (req, res) => {
  try {
    const { db, creditTransactionsTable } = await import("@workspace/db");
    const { sql } = await import("drizzle-orm");

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [overall] = await db
      .select({
        totalEarned: sql<number>`coalesce(sum(case when type = 'earned' or type = 'bonus' then amount else 0 end), 0)::float`,
        totalSpent: sql<number>`coalesce(sum(case when type = 'spent' then amount else 0 end), 0)::float`,
      })
      .from(creditTransactionsTable);

    const [monthly] = await db
      .select({
        earned: sql<number>`coalesce(sum(case when (type = 'earned' or type = 'bonus') and created_at >= ${startOfMonth.toISOString()} then amount else 0 end), 0)::float`,
      })
      .from(creditTransactionsTable);

    const balance = (overall?.totalEarned ?? 0) - (overall?.totalSpent ?? 0);

    const data = GetCreditsBalanceResponse.parse({
      balance,
      lifetimeEarned: overall?.totalEarned ?? 0,
      lifetimeSpent: overall?.totalSpent ?? 0,
      earnedThisMonth: monthly?.earned ?? 0,
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get credits balance");
    res.status(500).json({ error: "internal_error" });
  }
});

router.get("/credits/transactions", async (req, res) => {
  try {
    const { db, creditTransactionsTable } = await import("@workspace/db");
    const { sql, desc } = await import("drizzle-orm");

    const rows = await db
      .select()
      .from(creditTransactionsTable)
      .orderBy(desc(creditTransactionsTable.createdAt))
      .limit(50);

    const [countRow] = await db.select({ count: sql<number>`count(*)::int` }).from(creditTransactionsTable);

    const data = GetCreditTransactionsResponse.parse({
      transactions: rows.map((r) => ({
        id: String(r.id),
        type: r.type,
        amount: r.amount,
        reason: r.reason,
        requestId: r.requestId ?? undefined,
        createdAt: r.createdAt.toISOString(),
      })),
      total: countRow?.count ?? 0,
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get credit transactions");
    res.status(500).json({ error: "internal_error" });
  }
});

export default router;
