import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import routingRouter from "./routing.js";
import analyticsRouter from "./analytics.js";
import modelsRouter from "./models.js";
import usersRouter from "./users.js";
import creditsRouter from "./credits.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(routingRouter);
router.use(analyticsRouter);
router.use(modelsRouter);
router.use(usersRouter);
router.use(creditsRouter);

export default router;
