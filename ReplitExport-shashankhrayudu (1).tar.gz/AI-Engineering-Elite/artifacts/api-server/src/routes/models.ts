import { Router, type IRouter } from "express";
import { GetModelsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

export const AVAILABLE_MODELS = [
  {
    id: "llama-3-8b",
    name: "Llama 3 8B",
    provider: "Meta",
    tier: "budget" as const,
    costPer1kTokens: 0.00008,
    avgLatencyMs: 320,
    isAvailable: true,
    totalRequests: 0,
    successRate: 99.2,
    description: "Fast, efficient model for simple Q&A and text tasks",
  },
  {
    id: "claude-haiku",
    name: "Claude Haiku",
    provider: "Anthropic",
    tier: "budget" as const,
    costPer1kTokens: 0.00025,
    avgLatencyMs: 450,
    isAvailable: true,
    totalRequests: 0,
    successRate: 99.5,
    description: "Quick, capable model for summarization and basic reasoning",
  },
  {
    id: "gemini-flash",
    name: "Gemini 1.5 Flash",
    provider: "Google",
    tier: "standard" as const,
    costPer1kTokens: 0.00035,
    avgLatencyMs: 580,
    isAvailable: true,
    totalRequests: 0,
    successRate: 98.8,
    description: "Balanced speed and quality for moderate complexity tasks",
  },
  {
    id: "gpt-4o-mini",
    name: "GPT-4o Mini",
    provider: "OpenAI",
    tier: "standard" as const,
    costPer1kTokens: 0.00015,
    avgLatencyMs: 650,
    isAvailable: true,
    totalRequests: 0,
    successRate: 99.1,
    description: "Cost-effective GPT-4 class model for everyday tasks",
  },
  {
    id: "gpt-4o",
    name: "GPT-4o",
    provider: "OpenAI",
    tier: "premium" as const,
    costPer1kTokens: 0.005,
    avgLatencyMs: 1200,
    isAvailable: true,
    totalRequests: 0,
    successRate: 99.9,
    description: "Top-tier reasoning, coding, and complex analysis tasks",
  },
  {
    id: "claude-opus",
    name: "Claude Opus",
    provider: "Anthropic",
    tier: "premium" as const,
    costPer1kTokens: 0.015,
    avgLatencyMs: 1800,
    isAvailable: true,
    totalRequests: 0,
    successRate: 99.7,
    description: "Most capable model for expert-level reasoning and research",
  },
];

router.get("/models", async (req, res) => {
  try {
    const { db, routingRequestsTable } = await import("@workspace/db");
    const { sql } = await import("drizzle-orm");

    const counts = await db
      .select({
        modelId: routingRequestsTable.selectedModelId,
        count: sql<number>`count(*)::int`,
      })
      .from(routingRequestsTable)
      .groupBy(routingRequestsTable.selectedModelId);

    const countMap = new Map(counts.map((c) => [c.modelId, c.count]));

    const models = AVAILABLE_MODELS.map((m) => ({
      ...m,
      totalRequests: countMap.get(m.id) ?? 0,
    }));

    const data = GetModelsResponse.parse({ models });
    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get models");
    res.status(500).json({ error: "internal_error" });
  }
});

export default router;
