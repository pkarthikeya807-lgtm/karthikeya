import { Router, type IRouter } from "express";
import {
  GetAnalyticsOverviewResponse,
  GetRequestHistoryResponse,
  GetTimeseriesResponse,
  GetRequestHistoryQueryParams,
  GetTimeseriesQueryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/analytics/overview", async (req, res) => {
  try {
    const { db, routingRequestsTable, creditTransactionsTable } = await import("@workspace/db");
    const { sql } = await import("drizzle-orm");

    const [totals] = await db
      .select({
        totalRequests: sql<number>`count(*)::int`,
        totalTokens: sql<number>`coalesce(sum(tokens_used), 0)::int`,
        totalCost: sql<number>`coalesce(sum(cost_usd), 0)::float`,
        avgLatency: sql<number>`coalesce(avg(latency_ms), 0)::float`,
        failoverCount: sql<number>`sum(case when failover then 1 else 0 end)::int`,
        successCount: sql<number>`sum(case when success then 1 else 0 end)::int`,
      })
      .from(routingRequestsTable);

    const complexityRows = await db
      .select({
        complexity: routingRequestsTable.complexity,
        count: sql<number>`count(*)::int`,
      })
      .from(routingRequestsTable)
      .groupBy(routingRequestsTable.complexity);

    const modelRows = await db
      .select({
        modelId: routingRequestsTable.selectedModelId,
        modelName: routingRequestsTable.selectedModelName,
        count: sql<number>`count(*)::int`,
      })
      .from(routingRequestsTable)
      .groupBy(routingRequestsTable.selectedModelId, routingRequestsTable.selectedModelName)
      .orderBy(sql`count(*) desc`);

    const [creditsRow] = await db
      .select({
        totalEarned: sql<number>`coalesce(sum(amount), 0)::float`,
      })
      .from(creditTransactionsTable);

    const totalRequests = totals?.totalRequests ?? 0;
    const complexityMap: Record<string, number> = { simple: 0, moderate: 0, complex: 0 };
    for (const row of complexityRows) {
      if (row.complexity in complexityMap) complexityMap[row.complexity] = row.count;
    }

    const modelUsageBreakdown = modelRows.map((r) => ({
      modelId: r.modelId,
      modelName: r.modelName,
      requestCount: r.count,
      percentage: totalRequests > 0 ? Math.round((r.count / totalRequests) * 100 * 10) / 10 : 0,
    }));

    const premiumCostPer1k = 0.005;
    const budgetCostPer1k = 0.00015;
    const avgSavingsPerToken = premiumCostPer1k - budgetCostPer1k;
    const simpleRequests = complexityMap.simple;
    const estimatedSavings = (simpleRequests * 150 * avgSavingsPerToken) / 1000;

    const data = GetAnalyticsOverviewResponse.parse({
      totalRequests,
      totalTokensUsed: totals?.totalTokens ?? 0,
      totalCostUsd: totals?.totalCost ?? 0,
      totalSavingsUsd: Math.max(0, estimatedSavings),
      avgLatencyMs: Math.round(totals?.avgLatency ?? 0),
      creditsEarned: creditsRow?.totalEarned ?? 0,
      complexityBreakdown: complexityMap,
      modelUsageBreakdown,
      successRate: totalRequests > 0 ? Math.round(((totals?.successCount ?? 0) / totalRequests) * 100 * 10) / 10 : 100,
      failoverCount: totals?.failoverCount ?? 0,
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get overview");
    res.status(500).json({ error: "internal_error" });
  }
});

router.get("/analytics/requests", async (req, res) => {
  try {
    const params = GetRequestHistoryQueryParams.parse(req.query);
    const { db, routingRequestsTable } = await import("@workspace/db");
    const { sql, eq, desc } = await import("drizzle-orm");

    let query = db.select().from(routingRequestsTable).$dynamic();

    if (params.complexity) {
      query = query.where(eq(routingRequestsTable.complexity, params.complexity));
    }
    if (params.modelId) {
      query = query.where(eq(routingRequestsTable.selectedModelId, params.modelId));
    }

    const rows = await query
      .orderBy(desc(routingRequestsTable.createdAt))
      .limit(params.limit ?? 20)
      .offset(params.offset ?? 0);

    const [countRow] = await db.select({ count: sql<number>`count(*)::int` }).from(routingRequestsTable);

    const data = GetRequestHistoryResponse.parse({
      requests: rows.map((r) => ({
        id: String(r.id),
        prompt: r.prompt,
        complexity: r.complexity,
        complexityScore: r.complexityScore,
        selectedModelId: r.selectedModelId,
        selectedModelName: r.selectedModelName,
        tokensUsed: r.tokensUsed,
        costUsd: r.costUsd,
        latencyMs: r.latencyMs,
        creditsEarned: r.creditsEarned,
        success: r.success,
        failover: r.failover,
        createdAt: r.createdAt.toISOString(),
      })),
      total: countRow?.count ?? 0,
      limit: params.limit ?? 20,
      offset: params.offset ?? 0,
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get request history");
    res.status(500).json({ error: "internal_error" });
  }
});

router.get("/analytics/timeseries", async (req, res) => {
  try {
    const params = GetTimeseriesQueryParams.parse(req.query);
    const period = params.period ?? "day";
    const { pool } = await import("@workspace/db");

    let truncate = "day";
    let points = 7;
    if (period === "hour") { truncate = "hour"; points = 24; }
    else if (period === "week") { truncate = "day"; points = 30; }

    const query = `
      SELECT
        date_trunc('${truncate}', created_at)::text AS ts,
        count(*)::int AS requests,
        coalesce(sum(tokens_used), 0)::int AS tokens_used,
        coalesce(sum(cost_usd), 0)::float AS cost_usd,
        coalesce(avg(latency_ms), 0)::float AS avg_latency
      FROM routing_requests
      GROUP BY date_trunc('${truncate}', created_at)
      ORDER BY date_trunc('${truncate}', created_at) ASC
      LIMIT $1
    `;

    const result = await pool.query(query, [points]);
    const rows = result.rows;

    const premiumCostPer1k = 0.005;
    const budgetCostPer1k = 0.00015;

    const data = GetTimeseriesResponse.parse({
      period,
      data: rows.map((r: Record<string, number | string>) => ({
        timestamp: r.ts,
        requests: r.requests,
        tokensUsed: r.tokens_used ?? 0,
        costUsd: r.cost_usd ?? 0,
        avgLatencyMs: Math.round((r.avg_latency as number) ?? 0),
        savingsUsd: Math.max(0, ((r.tokens_used as number) ?? 0) * (premiumCostPer1k - budgetCostPer1k) / 1000 * 0.5),
      })),
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get timeseries");
    res.status(500).json({ error: "internal_error" });
  }
});

export default router;
