import { Router, type IRouter } from "express";
import { GetCurrentUserResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/users/me", async (req, res) => {
  try {
    const { db, routingRequestsTable, creditTransactionsTable } = await import("@workspace/db");
    const { sql } = await import("drizzle-orm");

    const [stats] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(routingRequestsTable);

    const [credits] = await db
      .select({ balance: sql<number>`coalesce(sum(case when type = 'earned' then amount when type = 'spent' then -amount else 0 end), 0)::float` })
      .from(creditTransactionsTable);

    const data = GetCurrentUserResponse.parse({
      id: "demo-user",
      name: "Demo User",
      email: "demo@openrouter.ai",
      apiKey: "sk-or-" + "x".repeat(8) + "****" + "x".repeat(4),
      plan: "pro",
      totalRequests: stats?.count ?? 0,
      creditsBalance: credits?.balance ?? 0,
      memberSince: "2024-01-15T00:00:00.000Z",
    });

    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get user");
    res.status(500).json({ error: "internal_error" });
  }
});

export default router;
