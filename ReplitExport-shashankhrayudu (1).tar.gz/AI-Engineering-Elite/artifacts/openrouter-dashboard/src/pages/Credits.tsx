import { AppLayout } from "@/components/layout/AppLayout";
import { GlassCard } from "@/components/ui/glass-card";
import { useGetCreditsBalance, useGetCreditTransactions } from "@workspace/api-client-react";
import { CreditCard, TrendingUp, TrendingDown, Gift, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function Credits() {
  const { data: balance, isLoading: balanceLoading, isError: balanceError } = useGetCreditsBalance();
  const { data: txs, isLoading: txsLoading } = useGetCreditTransactions();

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in duration-500">
        <header className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <CreditCard className="w-8 h-8 text-primary" />
            Credits & Billing
          </h1>
          <p className="text-muted-foreground mt-1">Manage your credit balance earned through efficient routing.</p>
        </header>

        {balanceError && (
          <div className="p-4 bg-warning/10 border border-warning/20 rounded-xl text-warning flex items-center gap-2 mb-6">
            <AlertTriangle className="w-5 h-5" />
            <span>Could not load credits balance. Backend API may be unconfigured.</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Balance Card */}
          <GlassCard className="p-8 lg:col-span-1 bg-gradient-to-br from-card/80 to-primary/5 flex flex-col items-center justify-center text-center relative overflow-hidden" glowEffect>
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary via-accent to-primary" />
            
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-widest mb-4">Available Balance</p>
            {balanceLoading ? (
               <div className="w-32 h-16 bg-muted/50 rounded-lg animate-pulse mb-2" />
            ) : (
               <h2 className="text-6xl font-display font-bold text-foreground tracking-tighter mb-2">
                 {balance?.balance.toFixed(2) || "0.00"}
               </h2>
            )}
            <p className="text-primary font-medium flex items-center gap-1">
              <Gift className="w-4 h-4" /> Routing Credits
            </p>

            <button className="mt-8 w-full py-3 px-4 bg-foreground text-background font-semibold rounded-xl hover:bg-foreground/90 transition-colors shadow-lg shadow-white/5 active:scale-95">
              Redeem Credits
            </button>
          </GlassCard>

          {/* Stats Summary */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
             <StatBox title="Lifetime Earned" value={balance?.lifetimeEarned} loading={balanceLoading} icon={TrendingUp} color="text-emerald-400" />
             <StatBox title="Lifetime Spent" value={balance?.lifetimeSpent} loading={balanceLoading} icon={TrendingDown} color="text-red-400" />
             <StatBox title="Earned This Month" value={balance?.earnedThisMonth} loading={balanceLoading} icon={TrendingUp} color="text-primary" />
          </div>
        </div>

        {/* Transactions Table */}
        <div className="mt-8">
          <h3 className="text-xl font-display font-semibold mb-4">Transaction History</h3>
          <GlassCard className="overflow-hidden">
             <div className="overflow-x-auto">
               <table className="w-full text-left text-sm">
                 <thead className="bg-muted/30 border-b border-border/50 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                   <tr>
                     <th className="px-6 py-4">Type</th>
                     <th className="px-6 py-4">Amount</th>
                     <th className="px-6 py-4">Reason</th>
                     <th className="px-6 py-4 text-right">Date</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-border/50">
                   {txsLoading ? (
                     [...Array(3)].map((_, i) => (
                       <tr key={i} className="animate-pulse">
                         <td className="px-6 py-4"><div className="w-16 h-6 bg-muted rounded-full" /></td>
                         <td className="px-6 py-4"><div className="w-16 h-4 bg-muted rounded" /></td>
                         <td className="px-6 py-4"><div className="w-48 h-4 bg-muted rounded" /></td>
                         <td className="px-6 py-4 text-right"><div className="w-24 h-4 bg-muted rounded ml-auto" /></td>
                       </tr>
                     ))
                   ) : !txs || txs.transactions.length === 0 ? (
                     <tr>
                        <td colSpan={4} className="px-6 py-12 text-center text-muted-foreground">
                          No transactions found.
                        </td>
                     </tr>
                   ) : (
                     txs.transactions.map((tx) => (
                       <tr key={tx.id} className="hover:bg-muted/10 transition-colors">
                         <td className="px-6 py-4">
                           <TxBadge type={tx.type} />
                         </td>
                         <td className="px-6 py-4 font-mono font-medium">
                           <span className={tx.type === 'spent' ? 'text-red-400' : 'text-emerald-400'}>
                             {tx.type === 'spent' ? '-' : '+'}{tx.amount.toFixed(2)}
                           </span>
                         </td>
                         <td className="px-6 py-4 text-foreground/80">{tx.reason}</td>
                         <td className="px-6 py-4 text-right text-muted-foreground font-mono text-xs">
                           {format(new Date(tx.createdAt), "MMM d, yyyy HH:mm")}
                         </td>
                       </tr>
                     ))
                   )}
                 </tbody>
               </table>
             </div>
          </GlassCard>
        </div>
      </div>
    </AppLayout>
  );
}

function StatBox({ title, value, loading, icon: Icon, color }: any) {
  return (
    <GlassCard className="p-6 flex flex-col justify-center">
      <div className="flex items-center gap-2 mb-3">
        <div className={cn("p-1.5 rounded bg-background/50", color)}>
           <Icon className="w-4 h-4" />
        </div>
        <span className="text-sm font-medium text-muted-foreground">{title}</span>
      </div>
      {loading ? (
        <div className="w-24 h-8 bg-muted/50 rounded animate-pulse" />
      ) : (
        <span className="text-3xl font-display font-bold">{value?.toFixed(2) || "0.00"}</span>
      )}
    </GlassCard>
  )
}

function TxBadge({ type }: { type: string }) {
  const styles = {
    earned: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    spent: "bg-red-500/10 text-red-400 border-red-500/20",
    bonus: "bg-primary/10 text-primary border-primary/20",
  };
  const style = styles[type as keyof typeof styles] || styles.earned;

  return (
    <span className={cn("px-2.5 py-1 text-xs font-semibold rounded-full border capitalize", style)}>
      {type}
    </span>
  );
}
