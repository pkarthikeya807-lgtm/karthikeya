import { AppLayout } from "@/components/layout/AppLayout";
import { GlassCard } from "@/components/ui/glass-card";
import { useGetRequestHistory } from "@workspace/api-client-react";
import { History, Cpu, Clock, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function RequestHistory() {
  const { data, isLoading, isError } = useGetRequestHistory({ limit: 20, offset: 0 });

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in duration-500">
        <header className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <History className="w-8 h-8 text-primary" />
            Request History
          </h1>
          <p className="text-muted-foreground mt-1">Review past routing decisions, costs, and performance.</p>
        </header>

        <GlassCard className="overflow-hidden border border-border/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-muted/30 border-b border-border/50 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                <tr>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Prompt</th>
                  <th className="px-6 py-4">Model Used</th>
                  <th className="px-6 py-4">Complexity</th>
                  <th className="px-6 py-4 text-right">Tokens</th>
                  <th className="px-6 py-4 text-right">Cost</th>
                  <th className="px-6 py-4 text-right">Latency</th>
                  <th className="px-6 py-4 text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {isLoading ? (
                  [...Array(5)].map((_, i) => (
                    <tr key={i} className="animate-pulse">
                      <td className="px-6 py-4"><div className="w-4 h-4 bg-muted rounded-full" /></td>
                      <td className="px-6 py-4"><div className="w-48 h-4 bg-muted rounded" /></td>
                      <td className="px-6 py-4"><div className="w-24 h-4 bg-muted rounded" /></td>
                      <td className="px-6 py-4"><div className="w-16 h-6 bg-muted rounded-full" /></td>
                      <td className="px-6 py-4 text-right"><div className="w-10 h-4 bg-muted rounded ml-auto" /></td>
                      <td className="px-6 py-4 text-right"><div className="w-12 h-4 bg-muted rounded ml-auto" /></td>
                      <td className="px-6 py-4 text-right"><div className="w-12 h-4 bg-muted rounded ml-auto" /></td>
                      <td className="px-6 py-4 text-right"><div className="w-24 h-4 bg-muted rounded ml-auto" /></td>
                    </tr>
                  ))
                ) : isError ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-warning">
                      <div className="flex flex-col items-center gap-2">
                        <AlertTriangle className="w-8 h-8" />
                        <p>Failed to load request history. Backend API may be unconfigured.</p>
                      </div>
                    </td>
                  </tr>
                ) : data?.requests?.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-muted-foreground">
                      No requests found. Try sending a prompt first.
                    </td>
                  </tr>
                ) : (
                  data?.requests.map((req) => (
                    <tr key={req.id} className="hover:bg-muted/10 transition-colors">
                      <td className="px-6 py-4">
                        {req.success ? (
                          <CheckCircle2 className="w-5 h-5 text-success" />
                        ) : (
                          <XCircle className="w-5 h-5 text-destructive" />
                        )}
                      </td>
                      <td className="px-6 py-4 font-mono text-xs max-w-[300px] truncate text-foreground/80">
                        {req.prompt}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Cpu className="w-4 h-4 text-accent" />
                          <span className="font-medium">{req.selectedModelName}</span>
                          {req.failover && (
                            <span className="px-1.5 py-0.5 text-[10px] bg-warning/20 text-warning rounded-sm font-bold uppercase tracking-wider ml-1">
                              Failover
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <ComplexityBadge complexity={req.complexity} />
                      </td>
                      <td className="px-6 py-4 text-right font-mono text-muted-foreground">
                        {req.tokensUsed.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-right font-mono text-muted-foreground">
                        ${req.costUsd.toFixed(5)}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="flex items-center justify-end gap-1 text-muted-foreground font-mono">
                          <Clock className="w-3 h-3" /> {req.latencyMs}ms
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right text-muted-foreground text-xs">
                        {format(new Date(req.createdAt), "MMM d, HH:mm:ss")}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          {data && data.total > data.limit && (
             <div className="p-4 border-t border-border/50 bg-muted/10 flex justify-between items-center text-sm text-muted-foreground">
               <span>Showing {data.requests.length} of {data.total}</span>
               <div className="flex gap-2">
                 <button className="px-3 py-1.5 rounded bg-background border border-border hover:bg-muted transition-colors disabled:opacity-50">Previous</button>
                 <button className="px-3 py-1.5 rounded bg-background border border-border hover:bg-muted transition-colors disabled:opacity-50">Next</button>
               </div>
             </div>
          )}
        </GlassCard>
      </div>
    </AppLayout>
  );
}

function ComplexityBadge({ complexity }: { complexity: string }) {
  const colors = {
    simple: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    moderate: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    complex: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  };
  const color = colors[complexity as keyof typeof colors] || colors.simple;

  return (
    <span className={cn("px-2 py-0.5 text-xs font-medium rounded-full border capitalize", color)}>
      {complexity}
    </span>
  );
}
