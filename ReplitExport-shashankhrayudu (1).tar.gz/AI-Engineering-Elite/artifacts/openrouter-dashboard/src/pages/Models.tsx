import { AppLayout } from "@/components/layout/AppLayout";
import { GlassCard } from "@/components/ui/glass-card";
import { useGetModels } from "@workspace/api-client-react";
import { Cpu, Server, Zap, BarChart3, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Models() {
  const { data, isLoading, isError } = useGetModels();

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in duration-500">
        <header className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <Server className="w-8 h-8 text-primary" />
            Model Registry
          </h1>
          <p className="text-muted-foreground mt-1">Available LLMs configured for the routing engine.</p>
        </header>

        {isError && (
          <div className="p-6 bg-warning/10 border border-warning/20 rounded-xl text-warning flex items-center gap-3">
            <AlertTriangle className="w-6 h-6" />
            <div>
              <h3 className="font-bold">Failed to load models</h3>
              <p className="text-sm opacity-90">The backend API endpoint (/api/models) might not be implemented yet.</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {isLoading ? (
             [...Array(6)].map((_, i) => (
               <GlassCard key={i} className="p-6 h-[220px] animate-pulse bg-muted/20" />
             ))
          ) : (
            data?.models.map((model) => (
              <GlassCard key={model.id} className="p-6 flex flex-col justify-between hover:-translate-y-1 transition-transform duration-300">
                <div>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/20 flex items-center justify-center">
                        <Cpu className="w-5 h-5 text-foreground" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-lg leading-tight">{model.name}</h3>
                        <p className="text-xs text-muted-foreground">{model.provider}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                       <TierBadge tier={model.tier} />
                       <div className="flex items-center gap-1.5">
                         <div className={cn("w-2 h-2 rounded-full shadow-sm", model.isAvailable ? "bg-success shadow-success/50" : "bg-destructive shadow-destructive/50")} />
                         <span className="text-[10px] uppercase font-bold tracking-wider text-muted-foreground">
                           {model.isAvailable ? "Online" : "Offline"}
                         </span>
                       </div>
                    </div>
                  </div>
                  <p className="text-sm text-foreground/80 line-clamp-2 min-h-[40px] mb-4">
                    {model.description}
                  </p>
                </div>
                
                <div className="grid grid-cols-3 gap-3 border-t border-border/50 pt-4 mt-auto">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Cost/1k</span>
                    <span className="font-mono text-sm font-medium text-emerald-400">${model.costPer1kTokens.toFixed(4)}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 flex items-center gap-1"><Zap className="w-3 h-3"/> Latency</span>
                    <span className="font-mono text-sm font-medium text-amber-400">{model.avgLatencyMs}ms</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 flex items-center gap-1"><BarChart3 className="w-3 h-3"/> Success</span>
                    <span className="font-mono text-sm font-medium text-primary">{model.successRate.toFixed(1)}%</span>
                  </div>
                </div>
              </GlassCard>
            ))
          )}
        </div>
      </div>
    </AppLayout>
  );
}

function TierBadge({ tier }: { tier: string }) {
  const styles = {
    budget: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    standard: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    premium: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  };
  const style = styles[tier as keyof typeof styles] || styles.standard;

  return (
    <span className={cn("px-2 py-0.5 text-[10px] uppercase tracking-wider font-bold rounded-sm border", style)}>
      {tier}
    </span>
  );
}
