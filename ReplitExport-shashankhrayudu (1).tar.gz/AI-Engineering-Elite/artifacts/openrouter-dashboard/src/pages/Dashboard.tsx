import { AppLayout } from "@/components/layout/AppLayout";
import { PromptTester } from "@/components/PromptTester";
import { GlassCard } from "@/components/ui/glass-card";
import { cn } from "@/lib/utils";
import { useGetAnalyticsOverview, useGetTimeseries } from "@workspace/api-client-react";
import { 
  Activity, 
  Banknote, 
  PiggyBank, 
  Timer, 
  TrendingUp,
  AlertTriangle
} from "lucide-react";
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, Legend
} from "recharts";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: overview, isLoading: overviewLoading, isError: overviewError } = useGetAnalyticsOverview();
  const { data: timeseries, isLoading: timeLoading, isError: timeError } = useGetTimeseries({ period: 'day' });

  const formatMoney = (val: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(val);

  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto w-full space-y-8 animate-in fade-in duration-500 slide-in-from-bottom-4">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">Overview</h1>
            <p className="text-muted-foreground mt-1">Real-time metrics for your intelligent routing engine.</p>
          </div>
        </header>

        {/* Top Metrics Row */}
        {overviewLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <GlassCard key={i} className="h-28 animate-pulse bg-muted/20" />
            ))}
          </div>
        ) : overviewError ? (
           <div className="p-4 bg-warning/10 border border-warning/20 rounded-xl text-warning flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            <span>Could not load overview metrics. API may not be ready.</span>
           </div>
        ) : overview ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <StatCard title="Total Requests" value={overview.totalRequests.toLocaleString()} icon={Activity} color="text-blue-400" />
            <StatCard title="Total Cost" value={formatMoney(overview.totalCostUsd)} icon={Banknote} color="text-red-400" />
            <StatCard title="Total Savings" value={formatMoney(overview.totalSavingsUsd)} icon={PiggyBank} color="text-emerald-400" />
            <StatCard title="Avg Latency" value={`${overview.avgLatencyMs}ms`} icon={Timer} color="text-amber-400" />
            <StatCard title="Credits Earned" value={overview.creditsEarned.toLocaleString(undefined, {maximumFractionDigits: 0})} icon={TrendingUp} color="text-primary" />
          </div>
        ) : null}

        {/* Prompt Tester Section */}
        <section>
          <PromptTester />
        </section>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Timeseries Chart */}
          <GlassCard className="lg:col-span-2 p-6 flex flex-col min-h-[400px]">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Requests & Cost Over Time
            </h3>
            {timeLoading ? (
              <div className="flex-1 flex items-center justify-center"><div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"/></div>
            ) : timeError ? (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">Timeseries API unavailable</div>
            ) : timeseries?.data && timeseries.data.length > 0 ? (
              <div className="flex-1 w-full h-full min-h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timeseries.data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis 
                      dataKey="timestamp" 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={12}
                      tickFormatter={(val) => format(new Date(val), 'MMM dd')}
                    />
                    <YAxis yAxisId="left" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(val) => `$${val}`} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '12px' }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="requests" name="Requests" stroke="hsl(var(--primary))" strokeWidth={3} dot={false} activeDot={{ r: 6 }} />
                    <Line yAxisId="right" type="monotone" dataKey="costUsd" name="Cost (USD)" stroke="hsl(var(--accent))" strokeWidth={3} dot={false} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">No data available</div>
            )}
          </GlassCard>

          {/* Complexity Breakdown */}
          <GlassCard className="p-6 flex flex-col min-h-[400px]">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <PieChart className="w-5 h-5 text-accent" />
              Prompt Complexity
            </h3>
            {overviewLoading ? (
              <div className="flex-1 flex items-center justify-center"><div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"/></div>
            ) : overviewError ? (
               <div className="flex-1 flex items-center justify-center text-muted-foreground">Data unavailable</div>
            ) : overview ? (
              <div className="flex-1 w-full h-full relative flex items-center justify-center min-h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Simple', value: overview.complexityBreakdown.simple },
                        { name: 'Moderate', value: overview.complexityBreakdown.moderate },
                        { name: 'Complex', value: overview.complexityBreakdown.complex },
                      ]}
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      stroke="none"
                    >
                      <Cell fill="hsl(142 71% 45%)" /> {/* emerald */}
                      <Cell fill="hsl(38 92% 50%)" /> {/* amber */}
                      <Cell fill="hsl(262 83% 65%)" /> {/* purple */}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '12px' }}
                    />
                    <Legend verticalAlign="bottom" height={36} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : null}
          </GlassCard>

        </div>
      </div>
    </AppLayout>
  );
}

function StatCard({ title, value, icon: Icon, color }: { title: string, value: string, icon: any, color: string }) {
  return (
    <GlassCard className="p-5 flex flex-col justify-between" glowEffect>
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-medium text-muted-foreground">{title}</span>
        <div className={cn("p-2 rounded-lg bg-background/50", color)}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="text-2xl font-display font-bold tracking-tight text-foreground">
        {value}
      </div>
    </GlassCard>
  );
}
