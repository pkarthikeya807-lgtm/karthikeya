import { AppLayout } from "@/components/layout/AppLayout";
import { GlassCard } from "@/components/ui/glass-card";
import { useGetCurrentUser } from "@workspace/api-client-react";
import { User, Mail, Key, Copy, CheckCircle2, Shield, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function Profile() {
  const { data: user, isLoading, isError } = useGetCurrentUser();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!user?.apiKey) return;
    navigator.clipboard.writeText(user.apiKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const maskKey = (key?: string) => {
    if (!key) return "••••••••••••••••••••••••";
    return `${key.substring(0, 4)}••••••••••••••••${key.substring(key.length - 4)}`;
  };

  return (
    <AppLayout>
      <div className="p-8 max-w-4xl mx-auto w-full space-y-8 animate-in fade-in duration-500">
        <header className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <User className="w-8 h-8 text-primary" />
            Account Profile
          </h1>
          <p className="text-muted-foreground mt-1">Manage your settings and API credentials.</p>
        </header>

        {isError && (
          <div className="p-6 bg-warning/10 border border-warning/20 rounded-xl text-warning flex items-center gap-3">
            <AlertTriangle className="w-6 h-6" />
            <div>
              <h3 className="font-bold">Failed to load profile</h3>
              <p className="text-sm opacity-90">The backend API endpoint (/api/users/me) might not be implemented yet.</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <GlassCard className="p-6 flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-accent p-1 mb-4">
                <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
                  <User className="w-10 h-10 text-muted-foreground" />
                </div>
              </div>
              
              {isLoading ? (
                <div className="space-y-2 w-full flex flex-col items-center">
                  <div className="w-32 h-6 bg-muted rounded animate-pulse" />
                  <div className="w-48 h-4 bg-muted rounded animate-pulse" />
                </div>
              ) : (
                <>
                  <h2 className="text-xl font-bold font-display">{user?.name || "Developer"}</h2>
                  <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1 justify-center">
                    <Mail className="w-3 h-3" /> {user?.email || "dev@example.com"}
                  </p>
                  
                  <div className="mt-6 pt-6 border-t border-border/50 w-full flex flex-col gap-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Plan</span>
                      <span className="font-semibold text-primary capitalize">{user?.plan || "Free"}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Member Since</span>
                      <span className="font-medium text-foreground">
                        {user?.memberSince ? format(new Date(user.memberSince), "MMM yyyy") : "Jan 2024"}
                      </span>
                    </div>
                  </div>
                </>
              )}
            </GlassCard>
          </div>

          <div className="md:col-span-2 space-y-6">
            <GlassCard className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-accent" />
                API Credentials
              </h3>
              <p className="text-sm text-muted-foreground mb-6">
                Use this key to authenticate your routing requests. Keep it secret.
              </p>

              <div className="space-y-2">
                <label className="text-xs font-medium text-foreground/80 uppercase tracking-wider">Secret API Key</label>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-background/50 border border-border rounded-lg px-4 py-3 font-mono text-sm tracking-wider text-muted-foreground">
                    {isLoading ? "Loading..." : maskKey(user?.apiKey)}
                  </div>
                  <button 
                    onClick={handleCopy}
                    disabled={isLoading || !user?.apiKey}
                    className={cn(
                      "p-3 rounded-lg border transition-all duration-200 flex items-center justify-center min-w-[48px]",
                      copied 
                        ? "bg-success/10 border-success/30 text-success" 
                        : "bg-background border-border hover:bg-muted text-foreground"
                    )}
                  >
                    {copied ? <CheckCircle2 className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-border/50 flex justify-end">
                <button className="px-4 py-2 bg-destructive/10 text-destructive border border-destructive/20 rounded-lg text-sm font-medium hover:bg-destructive/20 transition-colors">
                  Roll API Key
                </button>
              </div>
            </GlassCard>

            <GlassCard className="p-6 bg-primary/5 border-primary/20">
               <h3 className="text-lg font-semibold text-primary mb-2">Upgrade to Pro</h3>
               <p className="text-sm text-foreground/80 mb-6 max-w-md">
                 Get priority access to premium models, lower latency guarantees, and advanced custom routing rules.
               </p>
               <button className="px-6 py-2.5 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 transition-all shadow-lg shadow-primary/25 active:scale-95">
                 View Pricing Plans
               </button>
            </GlassCard>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
