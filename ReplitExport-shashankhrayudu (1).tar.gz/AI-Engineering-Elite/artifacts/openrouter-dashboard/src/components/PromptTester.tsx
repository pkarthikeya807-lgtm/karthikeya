import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRoutePrompt } from "@workspace/api-client-react";
import { GlassCard } from "./ui/glass-card";
import { 
  Send, 
  Sparkles, 
  Zap, 
  Coins, 
  Clock, 
  Cpu, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle 
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { RouteResponse } from "@workspace/api-client-react";

export function PromptTester() {
  const [prompt, setPrompt] = useState("");
  const { mutate, isPending, data: response, isError, error } = useRoutePrompt();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    mutate({ data: { prompt } });
  };

  return (
    <GlassCard className="p-1 flex flex-col" glowEffect>
      <div className="p-5 border-b border-border/50 bg-card/30">
        <h2 className="text-xl font-display font-semibold flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          Live Routing Engine
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Test the intelligent router. Enter a prompt to see how it categorizes complexity and selects the optimal model.
        </p>
      </div>

      <div className="p-6">
        <form onSubmit={handleSubmit} className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="E.g., Write a python script to reverse a linked list..."
            className="w-full min-h-[120px] bg-background/50 border border-border rounded-xl p-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 resize-none font-mono text-sm shadow-inner transition-all duration-200"
          />
          <div className="absolute bottom-3 right-3 flex gap-2">
            <button
              type="submit"
              disabled={isPending || !prompt.trim()}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm flex items-center gap-2 hover:bg-primary/90 hover:shadow-[0_0_15px_hsl(var(--primary)/0.3)] disabled:opacity-50 disabled:pointer-events-none transition-all duration-200"
            >
              {isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                  Routing...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Route Request
                </>
              )}
            </button>
          </div>
        </form>

        <AnimatePresence mode="wait">
          {isError && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive flex items-center gap-3"
            >
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p className="text-sm">Routing failed. The backend API might not be implemented yet. ({error?.message || "Unknown error"})</p>
            </motion.div>
          )}

          {response && !isPending && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="mt-6 space-y-4"
            >
              <div className="flex items-center gap-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Routing Decision</h3>
                <div className="flex-1 h-px bg-border/50" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Decision Info */}
                <div className="bg-background/40 rounded-xl border border-border p-5 shadow-inner">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Selected Model</p>
                      <div className="flex items-center gap-2">
                        <Cpu className="w-5 h-5 text-accent" />
                        <span className="font-display font-bold text-lg">{response.selectedModel.name}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Provider: {response.selectedModel.provider}</p>
                    </div>
                    <Badge complexity={response.complexity} />
                  </div>

                  <div className="bg-muted/30 rounded-lg p-3 border border-border/50">
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Routing Reason
                    </p>
                    <p className="text-sm leading-relaxed">{response.routingReason}</p>
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-3">
                  <MetricBox 
                    icon={Coins} 
                    label="Estimated Cost" 
                    value={`$${response.costUsd.toFixed(5)}`}
                    color="text-emerald-400"
                  />
                  <MetricBox 
                    icon={Zap} 
                    label="Tokens Used" 
                    value={response.tokensUsed.toLocaleString()}
                    color="text-amber-400"
                  />
                  <MetricBox 
                    icon={Clock} 
                    label="Latency" 
                    value={`${response.latencyMs}ms`}
                    color="text-blue-400"
                  />
                  <MetricBox 
                    icon={CheckCircle2} 
                    label="Credits Earned" 
                    value={`+${response.creditsEarned.toFixed(2)}`}
                    color="text-primary"
                  />
                </div>
              </div>

              {/* Simulated Output */}
              <div className="bg-background/40 rounded-xl border border-border p-5">
                <p className="text-xs font-mono text-muted-foreground mb-3 uppercase tracking-wider flex items-center gap-2">
                  <ArrowRight className="w-3 h-3" /> Output from {response.selectedModel.name}
                </p>
                <div className="prose prose-invert prose-sm max-w-none text-foreground/90 font-mono text-sm whitespace-pre-wrap leading-relaxed">
                  {response.response}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </GlassCard>
  );
}

function Badge({ complexity }: { complexity: string }) {
  const colors = {
    simple: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    moderate: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    complex: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  };
  const color = colors[complexity as keyof typeof colors] || colors.simple;

  return (
    <span className={cn("px-2.5 py-1 text-xs font-semibold rounded-full border capitalize shadow-sm", color)}>
      {complexity}
    </span>
  );
}

function MetricBox({ icon: Icon, label, value, color }: { icon: any, label: string, value: string | number, color: string }) {
  return (
    <div className="bg-background/40 rounded-xl border border-border p-4 flex flex-col justify-center">
      <div className="flex items-center gap-2 mb-2">
        <Icon className={cn("w-4 h-4", color)} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <span className="font-mono text-xl font-medium tracking-tight">{value}</span>
    </div>
  );
}
