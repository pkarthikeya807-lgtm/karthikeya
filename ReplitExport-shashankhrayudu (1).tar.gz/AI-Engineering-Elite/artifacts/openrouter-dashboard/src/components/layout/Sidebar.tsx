import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Network, 
  LayoutDashboard, 
  History, 
  Cpu, 
  CreditCard, 
  User,
  Zap
} from "lucide-react";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/history", label: "Request History", icon: History },
  { href: "/models", label: "Models", icon: Cpu },
  { href: "/credits", label: "Credits", icon: CreditCard },
  { href: "/profile", label: "Profile", icon: User },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 flex-shrink-0 flex flex-col border-r border-border/50 bg-card/30 backdrop-blur-xl h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3 border-b border-border/50">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
          <Network className="w-5 h-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="font-display font-bold text-lg leading-tight bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/70">
            OpenRouter AI
          </h1>
          <p className="text-[10px] text-primary uppercase tracking-wider font-semibold flex items-center gap-1">
            <Zap className="w-3 h-3" /> Smart Routing
          </p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.href} href={item.href} className="block">
              <div
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group cursor-pointer",
                  isActive 
                    ? "bg-primary/10 text-primary border border-primary/20 shadow-inner" 
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50 border border-transparent"
                )}
              >
                <Icon className={cn("w-5 h-5 transition-transform duration-200", isActive ? "scale-110" : "group-hover:scale-110")} />
                <span className="font-medium text-sm">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-6 border-t border-border/50">
        <div className="bg-gradient-to-br from-secondary to-background rounded-xl p-4 border border-border/50 shadow-inner">
          <p className="text-xs text-muted-foreground mb-1">System Status</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse shadow-[0_0_8px_hsl(var(--success))]" />
            <span className="text-sm font-medium text-foreground">All systems operational</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
