import { pgTable, text, serial, real, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const routingRequestsTable = pgTable("routing_requests", {
  id: serial("id").primaryKey(),
  requestId: text("request_id").notNull().unique(),
  userId: text("user_id").default("demo-user"),
  prompt: text("prompt").notNull(),
  complexity: text("complexity").notNull(),
  complexityScore: real("complexity_score").notNull(),
  selectedModelId: text("selected_model_id").notNull(),
  selectedModelName: text("selected_model_name").notNull(),
  tokensUsed: integer("tokens_used").notNull(),
  costUsd: real("cost_usd").notNull(),
  latencyMs: integer("latency_ms").notNull(),
  creditsEarned: real("credits_earned").notNull().default(0),
  success: boolean("success").notNull().default(true),
  failover: boolean("failover").notNull().default(false),
  routingReason: text("routing_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertRoutingRequestSchema = createInsertSchema(routingRequestsTable).omit({ id: true, createdAt: true });
export type InsertRoutingRequest = z.infer<typeof insertRoutingRequestSchema>;
export type RoutingRequest = typeof routingRequestsTable.$inferSelect;
