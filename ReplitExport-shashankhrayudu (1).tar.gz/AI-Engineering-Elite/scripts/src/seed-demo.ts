import { db, routingRequestsTable, creditTransactionsTable } from "@workspace/db";
import { randomUUID } from "crypto";

const models = [
  { id: "llama-3-8b", name: "Llama 3 8B", tier: "budget", cost: 0.00008 },
  { id: "claude-haiku", name: "Claude Haiku", tier: "budget", cost: 0.00025 },
  { id: "gemini-flash", name: "Gemini 1.5 Flash", tier: "standard", cost: 0.00035 },
  { id: "gpt-4o-mini", name: "GPT-4o Mini", tier: "standard", cost: 0.00015 },
  { id: "gpt-4o", name: "GPT-4o", tier: "premium", cost: 0.005 },
  { id: "claude-opus", name: "Claude Opus", tier: "premium", cost: 0.015 },
];

const complexities: Array<{ complexity: "simple" | "moderate" | "complex"; modelTier: string; score: [number, number] }> = [
  { complexity: "simple", modelTier: "budget", score: [0.05, 0.28] },
  { complexity: "moderate", modelTier: "standard", score: [0.3, 0.64] },
  { complexity: "complex", modelTier: "premium", score: [0.65, 0.99] },
];

const samplePrompts = [
  "What is the capital of France?",
  "Define machine learning in one sentence.",
  "Translate 'Hello World' to Spanish.",
  "Explain the difference between REST and GraphQL APIs.",
  "How does transformer architecture work in LLMs?",
  "Analyze the trade-offs between microservices and monolithic architectures in high-traffic systems.",
  "Write a comprehensive guide on optimizing database query performance.",
  "Design a distributed caching strategy for a global e-commerce platform.",
  "What time is it in Tokyo?",
  "List the top 5 programming languages.",
  "Compare Python and JavaScript for backend development.",
  "Implement a rate limiter algorithm with Redis.",
  "What causes climate change?",
  "How does blockchain consensus work?",
  "Build a full authentication system with JWT and refresh tokens.",
];

function rand(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

async function seed() {
  const now = Date.now();
  const sevenDaysAgo = now - 7 * 24 * 60 * 60 * 1000;

  const requests = [];
  const credits = [];

  for (let i = 0; i < 150; i++) {
    const timestamp = new Date(rand(sevenDaysAgo, now));
    const compConfig = complexities[Math.floor(Math.random() * complexities.length)];
    const eligibleModels = models.filter((m) => m.tier === compConfig.modelTier);
    const model = eligibleModels[Math.floor(Math.random() * eligibleModels.length)];
    const prompt = samplePrompts[Math.floor(Math.random() * samplePrompts.length)];
    const score = rand(compConfig.score[0], compConfig.score[1]);
    const tokens = Math.floor(rand(80, 600));
    const cost = (tokens / 1000) * model.cost;
    const latency = Math.floor(rand(200, 2000));
    const creditsEarned = compConfig.complexity === "simple" ? rand(8, 15) : compConfig.complexity === "moderate" ? rand(2, 5) : rand(0.5, 2);
    const requestId = randomUUID();

    requests.push({
      requestId,
      userId: "demo-user",
      prompt,
      complexity: compConfig.complexity,
      complexityScore: parseFloat(score.toFixed(3)),
      selectedModelId: model.id,
      selectedModelName: model.name,
      tokensUsed: tokens,
      costUsd: parseFloat(cost.toFixed(6)),
      latencyMs: latency,
      creditsEarned: parseFloat(creditsEarned.toFixed(2)),
      success: Math.random() > 0.02,
      failover: Math.random() < 0.03,
      routingReason: compConfig.complexity === "simple"
        ? "Short factual query routed to budget model"
        : compConfig.complexity === "moderate"
        ? "Moderate complexity routed to standard model"
        : "Complex reasoning task routed to premium model",
    });

    if (creditsEarned > 0) {
      credits.push({
        transactionId: randomUUID(),
        userId: "demo-user",
        type: "earned" as const,
        amount: parseFloat(creditsEarned.toFixed(2)),
        reason: `Efficient routing: ${compConfig.complexity} → ${model.name}`,
        requestId,
      });
    }
  }

  for (let i = 0; i < requests.length; i += 50) {
    await db.insert(routingRequestsTable).values(requests.slice(i, i + 50));
    if (credits.slice(i, i + 50).length > 0) {
      await db.insert(creditTransactionsTable).values(credits.slice(i, i + 50));
    }
  }

  console.log(`Seeded ${requests.length} routing requests and ${credits.length} credit transactions`);
  process.exit(0);
}

seed().catch((e) => { console.error(e); process.exit(1); });
